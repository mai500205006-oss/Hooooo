import { useEffect, useMemo, useState } from 'react';
import { logger } from '@utils/logger';
import {
  mockBackupHistory,
  mockImportPreview,
  mockModules,
  mockValidationChecks,
} from './data.mock';
import type { BackupEntry, ModuleOption, OperationStatus } from './types';

const MODULES_STORAGE_KEY = 'red_king.import_export.modules.v1';
const BACKUP_HISTORY_STORAGE_KEY = 'red_king.import_export.backup_history.v1';
const PROGRESS_STEP_MS = 180;

function loadModules(): ModuleOption[] {
  try {
    const raw = localStorage.getItem(MODULES_STORAGE_KEY);
    if (!raw) return mockModules;
    const parsed = JSON.parse(raw) as ModuleOption[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : mockModules;
  } catch (error) {
    logger.warn('Failed to read modules from Local Storage — falling back to mock data', { error }, 'import-export');
    return mockModules;
  }
}

function saveModules(modules: ModuleOption[]): void {
  try {
    localStorage.setItem(MODULES_STORAGE_KEY, JSON.stringify(modules));
  } catch (error) {
    logger.error('Failed to persist modules to Local Storage', error, 'import-export');
  }
}

function loadBackupHistory(): BackupEntry[] {
  try {
    const raw = localStorage.getItem(BACKUP_HISTORY_STORAGE_KEY);
    if (!raw) return mockBackupHistory;
    const parsed = JSON.parse(raw) as BackupEntry[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : mockBackupHistory;
  } catch (error) {
    logger.warn('Failed to read backup history from Local Storage — falling back to mock data', { error }, 'import-export');
    return mockBackupHistory;
  }
}

function saveBackupHistory(backupHistory: BackupEntry[]): void {
  try {
    localStorage.setItem(BACKUP_HISTORY_STORAGE_KEY, JSON.stringify(backupHistory));
  } catch (error) {
    logger.error('Failed to persist backup history to Local Storage', error, 'import-export');
  }
}

function useSimulatedProgress() {
  const [status, setStatus] = useState<OperationStatus>('idle');
  const [percent, setPercent] = useState(0);

  const run = (shouldFail = false) => {
    setStatus('running');
    setPercent(0);
    let current = 0;
    const timer = window.setInterval(() => {
      current += 10 + Math.round(Math.random() * 15);
      if (current >= 100) {
        current = 100;
        window.clearInterval(timer);
        setStatus(shouldFail ? 'error' : 'success');
      }
      setPercent(current);
    }, PROGRESS_STEP_MS);
  };

  const reset = () => {
    setStatus('idle');
    setPercent(0);
  };

  return { status, percent, run, reset };
}

export function useImportExport() {
  const [isLoading, setIsLoading] = useState(true);
  const [modules, setModules] = useState<ModuleOption[]>([]);
  const [selectedModuleIds, setSelectedModuleIds] = useState<string[]>([]);
  const [backupHistory, setBackupHistory] = useState<BackupEntry[]>([]);
  const [importFileName, setImportFileName] = useState<string | null>(null);
  const [restoreTargetId, setRestoreTargetId] = useState<string | null>(null);

  const exportOp = useSimulatedProgress();
  const importOp = useSimulatedProgress();

  useEffect(() => {
    const loadedModules = loadModules();
    setModules(loadedModules);
    setSelectedModuleIds(loadedModules.map((m) => m.id));
    setBackupHistory(loadBackupHistory());
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (isLoading) return;
    saveModules(modules);
  }, [modules, isLoading]);

  useEffect(() => {
    if (isLoading) return;
    saveBackupHistory(backupHistory);
  }, [backupHistory, isLoading]);

  const toggleModule = (id: string) => {
    setSelectedModuleIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]));
  };

  const startExport = () => exportOp.run(selectedModuleIds.length === 0);

  const chooseMockFile = () => {
    setImportFileName('red_king_backup_2026-07-24.json');
    importOp.reset();
  };

  const startImport = () => {
    if (!importFileName) return;
    importOp.run(false);
  };

  const conflictCount = useMemo(
    () => mockImportPreview.filter((p) => p.status === 'conflict').length,
    []
  );

  const validationChecks = useMemo(
    () =>
      mockValidationChecks.map((c) =>
        c.id === 'v3' && conflictCount > 0 ? { ...c, passed: false } : c
      ),
    [conflictCount]
  );

  const requestRestore = (id: string) => setRestoreTargetId(id);
  const cancelRestore = () => setRestoreTargetId(null);
  const confirmRestore = () => {
    setRestoreTargetId(null);
    importOp.run(false);
  };

  return {
    isLoading,
    modules,
    selectedModuleIds,
    toggleModule,
    exportStatus: exportOp.status,
    exportPercent: exportOp.percent,
    startExport,
    resetExport: exportOp.reset,
    importFileName,
    chooseMockFile,
    importPreview: mockImportPreview,
    validationChecks,
    importStatus: importOp.status,
    importPercent: importOp.percent,
    startImport,
    resetImport: importOp.reset,
    backupHistory,
    restoreTargetId,
    requestRestore,
    cancelRestore,
    confirmRestore,
  };
}
